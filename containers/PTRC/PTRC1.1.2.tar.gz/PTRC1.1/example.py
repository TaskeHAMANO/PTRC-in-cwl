__author__ = 'Tal Korem (tal.korem@gmail.com), David Zeevi (dave.zeevi@gmail.com), Eran Segal (eran.segal@weizmann.ac.il)'
__version__ = '1.1.0'
__date__ = 'December 4th 2015'

from PTRC import coverage_analysis, calculate_ptrs
from glob import glob
from os.path import join, basename
import logging
import argparse

def main(fastqfolder, gzpd, mapfolder, ptrfolder, outputdf, dbpath, csvout):
    for f in glob(join(fastqfolder, '*_1.fastq' + ('.gz' if gzpd else ''))):
        coverage_analysis(f, f.replace('_1.fastq', '_2.fastq'), \
                          join(mapfolder, basename(f).replace('_1.fastq', '').replace('.gz', '') + '.map'), \
                          True, gzpd, ptrfolder, dbpath = dbpath)
    for f in glob(join(fastqfolder, '*.fastq' + ('.gz' if gzpd else ''))):
        if '_1.fastq' not in f and '_2.fastq' not in f:
            coverage_analysis(f, None, join(mapfolder, basename(f).replace('.fastq', '').replace('.gz', '') + '.map'), \
                              False, gzpd, ptrfolder, dbpath = dbpath)
    calculate_ptrs(ptrfolder, outputdf, dbpath = dbpath, csv_output=csvout)
    
if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO, format = '%(asctime)s-%(levelname)s: %(message)s')
    parser = argparse.ArgumentParser()
    parser.add_argument('fastqfolder', help = 'Folder containing fastq files to operate on. Can contain mixed pe and se, labled with _1.fastq and _2.fastq')
    parser.add_argument('mapfolder', help = 'Folder that will contain created map files')
    parser.add_argument('ptrfolder', help = 'Folder that will contain temporary files per sample analyzed')
    parser.add_argument('outdf', help = 'Path of output pandas dataframe')
    parser.add_argument('-gz', action = 'store_true', help = 'Files are gzipped')
    parser.add_argument('-db_path_name', type = str, default = None, \
                        help = "Use this in case you used the DB command to create a new database. This should be the same as the 'out' parameter of the db command - meaning no extension (/path/to/name)")
    parser.add_argument('-csv_output', action = 'store_true', help = 'Will output a csv instead of pandas dataframe')
    args = parser.parse_args()
    main(args.fastqfolder, args.gz, args.mapfolder, args.ptrfolder, args.outdf, args.db_path_name, args.csv_output)