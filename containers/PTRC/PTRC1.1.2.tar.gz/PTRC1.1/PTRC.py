'''
This tool estimates bacterial growth by calculating peak-to-trough ratios 
(PTRs) as described in "Growth dynamics of gut microbiota in health and 
disease inferred from single metagenomic samples", Science 2015. 

*****************************************************************
*X*X*X*X*X*X*X*X*  PLEASE SEE ATTACHED LICENSE  *X*X*X*X*X*X*X*X*
*****************************************************************


Requirements:
^^^^^^^^^^^^^
1.  The GEM Mapper (Marco-Sola et. al. Nat. Methods 2014, available from
    gemlibrary.sourceforge.net. You need to have the binaries in your PATH
    variables, so that a simple call to "gem-mapper" would be successful.
2.  This code was written and tested on python 2.7.8, and requires the
    following packages:
    A. numpy (tested with 1.9.2)
    B. pandas (tested with 0.16.1)
    C. lmfit (tested with 0.8.2)
    D. dill (tested with 0.2.1)
    
Install:
^^^^^^^^
Extract index.gem.xz in the path with the code file. You're good to go.

Usage:
^^^^^^

****************************************************************
See the example.py for a non-parallelized simple implementation.
****************************************************************

The main code file is PTRC.py. You can either run it directly (python 
PTRC.py -h will get you started) or import the two main functions:
from PTRC import coverage_analysis, calculate_ptrs

The calculation contains two stages. The first one is coverage analysis,
which is performed per metagenomic sample by the method coverage_analysis 
or the CA command. This stage will save an output ptr file, used by the 
second stage. NOTE: It is recommended that you implement some sort of 
parallelization for this stage, depending on your system architecture.
 
The second stage calculates a consensus prediction per strain from all
the samples, and calculates PTRs. It is performed by the method 
calculate_ptrs or the PTR command. This receives as input the path of a
directory with ptr files created in the first stage.

Please note: with default parameters, PTRC will attempt to predict locations
of origins and termini of replication before calculating PTRs. In various 
datasets and settings we have found this to be the best practice. However,
note that for such a prediction to be made, the same strain has to exist 
with sufficient coverage in several samples. So for small datasets this 
might result in little or no PTRs calculated. In such cass, you can use
"-preds predetermined", in which case hardcoded origin and termini locations
will be used. 

DB command - requires a tsv file with 3 columns and no headers - a columns 
of fasta ids, a columns of species name, and a columns of origin location 
(which is optional). See example.fasta and example.tsv.

Change log:
^^^^^^^^^^^
Version 1.1:
- Added the DB command that allows the creation of new bacterial databases to work with.
- Added a CSV output option
- Updated README
'''

import logging
import argparse
from cptr import coverage_analysis, calculate_ptrs, create_new_db

__author__ = 'Tal Korem (tal.korem@gmail.com), David Zeevi (dave.zeevi@gmail.com), Eran Segal (eran.segal@weizmann.ac.il)'
__version__ = '1.1.0'
__date__ = 'December 4th 2015'

def _validateargs(args):
    assert args.i2 is None or args.pe, "No need for i2 if not pe."
    assert args.command != 'CA' or args.m is not None, "-m is required for CA command"
    assert args.command != 'CA' or args.outfol is not None, "-outfol is required for CA command"
    assert (not args.gz) or (args.i1 is not None), "-gz specified but no fastq files given"
    assert args.i1 is None or (not args.pe) or args.i2 is not None, "-pe specified but not i2"
    assert args.command != 'PTR' or args.infol is not None, "-infol is required for PTR command"
    assert args.command != 'PTR' or args.o is not None, "-o is required for PTR command"
    
def _addargs(parser):
    parser.add_argument('command', \
                        help = 'Operation to perform. CA - performs coverage analysis per single file. PTR - Calculates PTRs for a set of coverage-analyzed samples. DB - creates a new bactrial genomes database to work with', \
                        choices = ['CA', 'PTR', 'DB'])
    parser.add_argument('-cov_thresh', type = int, default = 5, \
                        help = "Minimal coverage required. This is the number of reads per 10Kbp bin, meaning that a value of 5 corresponds to a coverage of 0.05x (5 * 100bp read / 10kbp). Default 5")
    parser.add_argument('-db_path_name', type = str, default = None, \
                        help = "Use this in case you used the DB command to create a new database. This should be the same as the 'out' parameter of the db command - meaning no extension (/path/to/name)")
    cagroup = parser.add_argument_group('CA', 'Args for coverage analysis')
    cagroup.add_argument('-pe', action = 'store_true', \
                         help = 'Sample was originally mapped paired-end')
    cagroup.add_argument('-i1', help = 'Path to fastq file. If mapping pe, this should be the first end. If specified - GEM mapping will be performed.')
    cagroup.add_argument('-i2', help = 'Path to 2nd end of fastq file. Specify only if -pe.')
    cagroup.add_argument('-m', 
                         help = "Path to map file. If it doesn't exist yet - specify -i1 and -i2. Required.")
    cagroup.add_argument('-gz', action = 'store_true', help = 'fastq file/s are gzip-ed')
    cagroup.add_argument('-qual_format', choices = ['ignore', 'offset-33', 'offset-64'], \
                         default = 'offset-33', help = 'Fastq quality format, used by GEM-mapper. Default offset-33.')
    cagroup.add_argument('-outfol', \
                         help = 'Output folder in which the coverage analysis output will be stored. Required.')
    
    ptrgroup = parser.add_argument_group('PTR', 'Args for peak-to-trough ratio calculations')
    ptrgroup.add_argument('-infol', \
                          help = 'Folder containing .ptr files')
    ptrgroup.add_argument('-minpred', type = int, default = 3,\
                          help = 'Minimum number of successful origin and terminus location per strain required to obtain a census. Default 3.')
    ptrgroup.add_argument('-preds', default = 'generate', \
                          choices = ['generate', 'predetermined'],\
                          help = "Optionally use origin and terminus locations not based on current dataset. This is useful for small datasets. If you're using your own database, this uses the numbers supplied in the third columns. Otherwise, it will use the predictions used in Korem et. al. 2015, based on the datasets of Qin et. al. 2012 and Nielsen et. al. 2014. Default generate.")
    ptrgroup.add_argument('-o', help = 'Output file - pandas DataFrame containing PTRs')
    ptrgroup.add_argument('-opreds', help = 'Output file - optionally saves the predictions calculated')
    ptrgroup.add_argument('-csv_output', action = 'store_true', help = 'Will output a csv instead of pandas dataframe')
    dbgroup = parser.add_argument_group('DB', 'Args for database creation')
    dbgroup.add_argument('-metadata', help = 'A tab-delimited file, with no header, where each line is <fasta-id>\t<species>\t<location_of_origin>\n . The location of the origin is optional (both per line and in general).')
    dbgroup.add_argument('-fasta', help = 'The genomes to use')
    dbgroup.add_argument('-out', help = 'The path and name of the db. Do not specify an extension. (e.g., /path/to/name).')
                  
if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO, format = '%(asctime)s-%(levelname)s: %(message)s')
    parser = argparse.ArgumentParser()
    _addargs(parser)
    args = parser.parse_args()
    _validateargs(args)
    if args.command == 'CA':
        coverage_analysis(args.i1, args.i2, args.m, args.pe, args.gz, \
                          args.outfol, args.qual_format, args.cov_thresh, dbpath = args.db_path_name)
    elif args.command == 'PTR':
        calculate_ptrs(args.infol, args.o, args.minpred, args.preds, args.cov_thresh, args.opreds, \
                       dbpath = args.db_path_name, csv_output = args.csv_output)
    elif args.command == 'DB':
        create_new_db(args.metadata, args.fasta, args.out)
